const $=id=>document.getElementById(id);
const screens=[...document.querySelectorAll(".screen")];
const show=id=>screens.forEach(s=>s.classList.toggle("active",s.id===id));

const defaults={coins:0,power:1,health:1,speed:1,chapter:1,music:true,vibe:true,comfort:false,
 crit:1,range:1,combo:1,armor:1,regen:1,energy:1,dash:1};
let save={...defaults,...JSON.parse(localStorage.getItem("shadowLegacySaveV1")||"{}")};
save.chapter=Math.max(1,Math.min(3,save.chapter||1));
const persist=()=>localStorage.setItem("shadowLegacySaveV1",JSON.stringify(save));
let selectedCharacter=localStorage.getItem("shadowLegacyCharacter")||"kael";

const chars={
 kael:{name:"KAEL",icon:"⚔️",hp:100,speed:190,energy:100,damage:18},
 lyra:{name:"LYRA",icon:"🌙",hp:86,speed:225,energy:115,damage:16},
 darius:{name:"DARIUS",icon:"🛡️",hp:145,speed:155,energy:90,damage:24},
 nyx:{name:"NYX",icon:"🌀",hp:92,speed:215,energy:140,damage:15}
};

let running=false,paused=false,keys={},last=0,raf=0;
let player={x:17,y:0,hp:100,maxHp:100,energy:100,maxEnergy:100,vx:0,vy:0};
let enemies=[],boss={active:false,hp:100,maxHp:100,x:86};
let chapter=1,attackCooldown=0,dashCooldown=0,worldCoins=0;

function updateTop(){ $("coinsTop").textContent=save.coins; }
function selectCharacter(id){
 selectedCharacter=id;localStorage.setItem("shadowLegacyCharacter",id);
 document.querySelectorAll(".character-card").forEach(c=>c.classList.toggle("selected",c.dataset.character===id));
}
document.querySelectorAll(".character-card").forEach(c=>c.addEventListener("click",()=>selectCharacter(c.dataset.character)));
selectCharacter(selectedCharacter);

$("playBtn").onclick=()=>show("characters");
$("charactersBackBtn").onclick=()=>show("menu");
$("startChapterBtn").onclick=()=>startGame(save.chapter);
$("storyBtn").onclick=()=>show("story");
$("shopBtn").onclick=()=>{updateShop();show("shop")};
$("settingsBtn").onclick=()=>show("settings");
document.querySelectorAll(".backBtn").forEach(b=>b.onclick=()=>show("menu"));
document.querySelectorAll(".menuBtn").forEach(b=>b.onclick=()=>{stopGame();show("menu")});
$("retryBtn").onclick=()=>startGame(chapter);
$("nextBtn").onclick=()=>{if(chapter<3){save.chapter=Math.max(save.chapter,chapter+1);persist();startGame(save.chapter)}else{stopGame();show("menu")}};

const shopBase={power:30,health:30,speed:30,crit:45,range:40,combo:55,armor:50,regen:60,energy:40,dash:55};
document.querySelectorAll("[data-upgrade]").forEach(b=>b.onclick=()=>{
 const type=b.dataset.upgrade;
 const level=save[type]||1;
 const price=shopBase[type]+(level-1)*25;
 if(save.coins>=price){
   save.coins-=price;save[type]=level+1;persist();updateShop();updateTop();
 }
});
function updateShop(){
 Object.keys(shopBase).forEach(t=>{
   const el=$(t+"Price"); if(el) el.textContent=shopBase[t]+((save[t]||1)-1)*25;
 });
 $("shopCoins").textContent=save.coins;
 updateTop();
}
$("musicToggle").onchange=e=>{save.music=e.target.checked;persist()};
$("vibeToggle").onchange=e=>{save.vibe=e.target.checked;persist()};
$("comfortToggle").onchange=e=>{save.comfort=e.target.checked;persist()};
$("musicToggle").checked=save.music;$("vibeToggle").checked=save.vibe;$("comfortToggle").checked=save.comfort;

function chapterName(c){return c===1?"CHAPITRE I — RUINES D'ASTERIA":c===2?"CHAPITRE II — FORÊT DES MURMURES":"CHAPITRE III — CŒUR DU NÉANT"}
function startGame(c){
 chapter=c;running=true;paused=false;worldCoins=0;attackCooldown=0;dashCooldown=0;
 const ch=chars[selectedCharacter];
 player={x:17,y:0,hp:ch.hp+save.health*10,maxHp:ch.hp+save.health*10,energy:ch.energy+save.energy*12,maxEnergy:ch.energy+save.energy*12,vx:0,vy:0};
 enemies=[{x:55,hp:45,maxHp:45},{x:72,hp:55,maxHp:55}];
 boss={active:false,hp:100+chapter*35,maxHp:100+chapter*35,x:86};
 $("playerSkin").className="player-skin "+selectedCharacter;
 $("playerSkin").textContent=ch.icon;
 $("chapterBanner").textContent=chapterName(chapter);
 $("chapterLabel").textContent="CHAPITRE "+["I","II","III"][chapter-1];
 $("bossLabel").textContent="Boss : 0%";
 $("boss").style.display="none";
 show("game");updateGameUI();cancelAnimationFrame(raf);last=performance.now();raf=requestAnimationFrame(loop);
}
function stopGame(){running=false;cancelAnimationFrame(raf)}
function gameOver(){running=false;show("gameover")}
function victory(){
 running=false;save.coins+=25+chapter*10;persist();updateTop();
 $("victoryText").textContent=chapter<3?`Chapitre ${chapter} terminé ! +${25+chapter*10} 🪙`:"Le Cœur du Néant a été vaincu. +"+(25+chapter*10)+" 🪙";
 $("nextBtn").textContent=chapter<3?"CHAPITRE SUIVANT":"RETOUR AU MENU";show("victory");
}

function doAttack(){
 if(!running||paused||attackCooldown>0)return;
 const ch=chars[selectedCharacter];
 attackCooldown=.32;player.energy=Math.min(player.maxEnergy,player.energy+10+save.energy);
 const fx=$("attackFx");fx.style.display="block";fx.style.left=(player.x+5)+"%";fx.style.bottom="27%";fx.animate([{transform:"scale(.4) rotate(-20deg)",opacity:1},{transform:"scale(1.5) rotate(20deg)",opacity:0}],{duration:300});
 const range=(selectedCharacter==="darius"?15:13)+save.range*1.5;
 let damage=ch.damage+save.power*3;
 if(save.crit>1 && Math.random()<Math.min(.35,(save.crit-1)*.04)) damage*=1.8;
 damage+=Math.max(0,save.combo-1)*2;
 enemies.forEach(e=>{if(Math.abs(e.x-player.x)<range)e.hp-=damage});
 if(boss.active&&Math.abs(boss.x-player.x)<range){boss.hp-=damage;hitBoss()}
 enemies=enemies.filter(e=>e.hp>0);
 if(enemies.length===0&&!boss.active){boss.active=true;$("boss").style.display="grid"}
}
function hitBoss(){
 $("hitFx").style.display="block";$("hitFx").style.left=(boss.x-3)+"%";$("hitFx").style.bottom="34%";
 setTimeout(()=>$("hitFx").style.display="none",130);
 if(boss.hp<=0)victory();
}
function dash(){
 if(!running||paused||dashCooldown>0||player.energy<20)return;
 dashCooldown=Math.max(.25,.7-(save.dash-1)*.035);player.energy-=Math.max(8,20-(save.dash-1)*1.2);player.x=Math.min(90,player.x+10+Math.min(10,(save.dash-1)*1.2));
 $("player").animate([{transform:"scaleX(1)"},{transform:"scaleX(1.6)"},{transform:"scaleX(1)"}],{duration:220});
}
$("attackBtn").onclick=doAttack;$("dashBtn").onclick=dash;$("pauseBtn").onclick=()=>{paused=!paused};

document.querySelectorAll("[data-key]").forEach(b=>{
 const k=b.dataset.key;
 b.addEventListener("pointerdown",e=>{e.preventDefault();keys[k]=true});
 b.addEventListener("pointerup",e=>{e.preventDefault();keys[k]=false});
 b.addEventListener("pointercancel",()=>keys[k]=false);
 b.addEventListener("pointerleave",()=>keys[k]=false);
});
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.code==="Space")doAttack();if(e.key==="Shift")dash();if(e.key==="Escape")paused=!paused});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);

function update(dt){
 if(!running||paused)return;
 const ch=chars[selectedCharacter];
 let dx=0;if(keys.left||keys.arrowleft)dx-=1;if(keys.right||keys.arrowright)dx+=1;
 player.x=Math.max(4,Math.min(91,player.x+dx*(ch.speed+save.speed*8)*dt/100));
 if(keys.up||keys.arrowup)player.y=Math.max(-5,player.y-30*dt);
 if(keys.down||keys.arrowdown)player.y=Math.min(8,player.y+30*dt);
 attackCooldown=Math.max(0,attackCooldown-dt);dashCooldown=Math.max(0,dashCooldown-dt);
 player.energy=Math.min(player.maxEnergy,player.energy+dt*(8+ch.energy/30+save.energy*0.7));
 if(save.regen>1) player.hp=Math.min(player.maxHp,player.hp+dt*(save.regen-1)*0.7);
 enemies.forEach(e=>{
   if(e.hp<=0)return;
   const dir=player.x<e.x?-1:1;e.x+=dir*dt*5;
   if(Math.abs(e.x-player.x)<5)player.hp-=dt*Math.max(1,(5+chapter*2)-(save.armor-1)*0.8);
 });
 if(boss.active){
   boss.x=86;
   if(Math.abs(boss.x-player.x)<13)player.hp-=dt*(7+chapter*2);
 }
 if(player.hp<=0){gameOver();return}
 if(enemies.length===0&&!boss.active){boss.active=true;$("boss").style.display="grid"}
 updateGameUI();
}
function updateGameUI(){
 $("healthFill").style.width=Math.max(0,player.hp/player.maxHp*100)+"%";
 $("energyFill").style.width=Math.max(0,player.energy/player.maxEnergy*100)+"%";
 $("coinsWorld").querySelector("span").textContent=worldCoins;
 $("player").style.left=player.x+"%";$("player").style.transform=`translateY(${player.y}px)`;
 document.querySelector(".enemy-a").style.left=(enemies[0]?.x??-20)+"%";
 document.querySelector(".enemy-b").style.left=(enemies[1]?.x??-20)+"%";
 $("bossLabel").textContent=boss.active?"Boss : "+Math.max(0,Math.round((1-boss.hp/boss.maxHp)*100))+"%":"Ennemis : "+enemies.length;
}
function loop(t){const dt=Math.min(.033,(t-last)/1000);last=t;update(dt);if(running)raf=requestAnimationFrame(loop)}
updateTop();updateShop();
