SHADOW LEGACY V4 — JEU MOBILE

V4 conserve le menu, l'histoire, la boutique, les réglages et le choix des personnages de V3.
Nouveauté : une vraie scène de jeu visuelle avec décor, personnage animé par déplacement,
ennemis, boss, attaque et dash. Les quatre skins/personnages sont sélectionnables.

Fichiers à placer à la racine du dépôt GitHub Pages :
index.html
style.css
texture.css
game.js
README.txt

Le jeu fonctionne dans Safari sur iPhone.


V5 — BOUTIQUE AMÉLIORÉE
La V5 ajoute beaucoup plus d'améliorations dans la boutique sans modifier le reste du jeu :
- Combat : Puissance, Coup critique, Portée, Combo
- Défense : Vie, Armure, Régénération
- Mobilité/Énergie : Vitesse, Énergie, Dash
Chaque amélioration possède plusieurs niveaux et son prix augmente avec le niveau.
